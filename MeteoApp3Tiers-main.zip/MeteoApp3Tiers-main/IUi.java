package poo.ui;

public interface IUi {
	public void run();
}
